@extends('layout')
@section('content')
<style>
   .container {
      max-width: 450px;
   }
   .push-top {
      margin-top: 50px;
   }
</style>
<div class="row">
   <div class="col-lg-12 margin-tb">
      <div class="pull-right">
         <a class="btn btn-info" href="{{ route('items.index', ['page' => request('page', 1)]) }}">Back</a>
      </div>
   </div>
</div>
<div class="card push-top">
   <div class="card-header">
      Showing {{ $one_item->title }}
   </div>
   <div class="card-body">
      @if ($errors->any())
      <div class="alert alert-danger">
         <ul>
            @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
            @endforeach
         </ul>
      </div>
      <br />
      @endif

      <div class="form-group mb-2">
         <label><b>Title</b></label>
         <div>{{ $one_item->title }}</div>
      </div>

      <div class="form-group mb-2">
         <label><b>Item Type</b></label>
         <div>{{ $one_item->item_type }}</div>
      </div>

      <div class="form-group mb-2">
         <label><b>Publisher</b></label>
         <div>{{ $one_item->publisher_name }}</div>
      </div>

      @if ($one_item->item_type === 'book')
         <div class="form-group">
            <label><b>Author</b></label>
            <div>{{ $one_item->author_name ?? 'Unknown' }}</div>
         </div>
      @endif

      <div class="form-group">
         <label><b>Metadata</b></label>
         @php
            $metadata = is_string($one_item->metadata) ? json_decode($one_item->metadata, true) : $one_item->metadata;
         @endphp
         @foreach($metadata as $key => $value)
                @if ($key !== 'author_id')
                    <div class="row mb-1">
                        <div class="col-md-5">
                            <label for="{{ $key }}"><b>{{ $key }}</b></label>
                        </div>
                        <div class="col-md-7">
                            @if (is_array($value))
                                {{ implode(', ', $value) }}
                            @else
                                {{ $value }}
                            @endif
                        </div>
                    </div>
                @endif
         @endforeach
      </div>
   </div>
</div>
@endsection