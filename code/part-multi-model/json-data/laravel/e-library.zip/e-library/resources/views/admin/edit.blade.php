@extends('layout')
@section('content')
<style>
   .container {
      max-width: 450px;
   }
   .push-top {
      margin-top: 50px;
   }
</style>
<div class="row">
   <div class="col-lg-12 margin-tb">
      <div class="pull-right">
         <a class="btn btn-info" href="{{ route('items.index', ['page' => request('page', 1)]) }}">Back</a>
      </div>
   </div>
</div>
<div class="card push-top">
   <div class="card-header">
      Editing {{ $item->title }}
   </div>
   <div class="card-body">
      @if ($errors->any())
      <div class="alert alert-danger">
         <ul>
            @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
            @endforeach
         </ul>
      </div>
      <br />
      @endif
      <form method="post" action="{{ route('items.update', $item->id) }}">
         @csrf
         @method('PUT')

         <input type="hidden" name="page" value="{{ request('page', 1) }}">

         <div class="form-group">
            <label><b>Title</b></label>
            <input type="text" name="title" class="form-control" value="{{ old('title', $item->title) }}" required>
         </div>

         <div class="form-group">
            <label><b>Item Type</b></label>
            <input type="text" name="item_type" class="form-control" value="{{ old('item_type', $item->item_type) }}" required>
         </div>

         <div class="form-group">
            <label><b>Publisher</b></label>
            <select name="publisher_id" class="form-control" required>
               @foreach($publishers as $publisher)
                  <option value="{{ $publisher->id }}" {{ $item->publisher_id == $publisher->id ? 'selected' : '' }}>
                     {{ $publisher->name }}
                  </option>
               @endforeach
            </select>
         </div>

         @if($item->item_type === 'book')
         <div class="form-group">
            <label><b>Author</b></label>
            <select name="author_id" class="form-control" required>
               @foreach($authors as $author)
                  <option value="{{ $author->id }}" 
                     {{ (isset($item->metadata['author_id']) && $item->metadata['author_id'] == $author->id) ? 'selected' : '' }}>
                     {{ $author->name }}
                  </option>
               @endforeach
            </select>
         </div>
         @endif

         <div class="form-group">
            <label for="metadata"><b>Metadata</b></label>
            @foreach($item->metadata as $key => $value)
               @if ($key !== 'author_id') {{-- Skip author_id since we handle it above --}}
               <div class="row">
                  <div class="col-md-5" style="margin-bottom: 2px;">
                     <label for="{{ $key }}"><b>{{ $key }}</b></label>
                  </div>
                  <div class="col-md-5">
                     <input type="text" class="form-control" name="metadata[{{ $key }}]" 
                            value="{{ is_array($value) ? json_encode($value) : $value }}">
                  </div>
               </div>
               @endif
            @endforeach
         </div>

         <button type="submit" class="btn btn-block btn-danger">Update Item</button>
      </form>
   </div>
</div>
@endsection