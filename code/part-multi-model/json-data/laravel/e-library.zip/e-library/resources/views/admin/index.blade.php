@extends('layout')
@section('content')
<style>
   .push-top {
      margin-top: 50px;
   }
</style>

<div class="push-top">
   @if(session()->get('success'))
   <div class="alert alert-success">
      {{ session()->get('success') }}  
   </div>
   <br />
   @endif

   <table class="table table-bordered table-striped">
      <thead>
         <tr class="table-warning">
            <td>ID</td>
            <td>Title</td>
            <td>Item Type</td>
            <td>Publisher</td>
            <td>Metadata</td>
            <td class="text-center">Action</td>
         </tr>
      </thead>
      <tbody>
         @foreach($items as $item)
         <tr>
            <td>{{ $item->id }}</td>
            <td>{{ $item->title }}</td>
            <td>{{ $item->item_type }}</td>
            <td>{{ $item->publisher_name }}</td>
            <td>
               @php
                  $metadata = is_string($item->metadata) ? json_decode($item->metadata, true) : $item->metadata;
               @endphp
               @foreach ($metadata as $key => $value)
                  @php
                     $label = $key;
                     if ($key === 'author_id' && $item->item_type === 'book') {
                        $label = 'Author';
                        $value = $item->author_name ?? 'Unknown';
                     } elseif (is_array($value)) {
                        $value = implode(', ', $value);
                     }
                  @endphp
                  <b>{{ ucfirst($label) }}</b>: {{ $value }}<br />
               @endforeach
            </td>
            <td class="text-center">
               <a href="{{ route('items.show', ['item' => $item->id, 'page' => request('page', 1)]) }}" class="btn btn-info btn-sm">Show</a>
               <a href="{{ route('items.edit', ['item' => $item->id, 'page' => request('page', 1)]) }}" class="btn btn-primary btn-sm">Edit</a>
               <form action="{{ route('items.destroy', $item->id) }}" method="post" style="display: inline-block">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger btn-sm" type="submit">Delete</button>
               </form>
            </td>
         </tr>
         @endforeach
      </tbody>
   </table>

   <div>
      {!! $items->links() !!}
   </div>
</div>
@endsection