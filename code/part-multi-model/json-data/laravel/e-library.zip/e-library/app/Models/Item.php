<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    /** @use HasFactory<\Database\Factories\ItemFactory> */
    use HasFactory;

    public $timestamps = false;

    // Cast metadata JSON to array
    protected $casts = [
        "metadata" => "array",
    ];

    // Each item has a publisher
    public function publisher()
    {
        return $this->belongsTo("Publisher");
    }

    protected $fillable = ["title", "item_type", "publisher_id", "metadata"];
}
