<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreItemRequest;
use App\Http\Requests\UpdateItemRequest;
use App\Models\Author;
use App\Models\Publisher;
use App\Models\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $items = Item::select(
            "items.*",
            "publishers.name as publisher_name",
            DB::raw('CAST(metadata::$author_id AS SIGNED) as author_id'),
        )
            ->join("publishers", "publishers.id", "=", "items.publisher_id")
            ->leftJoin("authors", function ($join) {
                $join
                    ->on(
                        "authors.id",
                        "=",
                        DB::raw('CAST(items.metadata::$author_id AS SIGNED)'),
                    )
                    ->where("items.item_type", "=", "book");
            })
            ->addSelect("authors.name as author_name")
            ->orderBy("items.id")
            ->simplePaginate(5);

        return view("admin.index", compact("items"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreItemRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Item $item)
    {
        $one_item = Item::select("items.*", "publishers.name as publisher_name")
            ->join("publishers", "publishers.id", "=", "items.publisher_id")
            ->leftJoin("authors", function ($join) {
                $join
                    ->on(
                        "authors.id",
                        "=",
                        DB::raw('CAST(items.metadata::$author_id AS SIGNED)'),
                    )
                    ->where("items.item_type", "=", "book");
            })
            ->addSelect("authors.name as author_name")
            ->where("items.id", $item->id)
            ->first();

        return view("admin.show", compact("one_item"));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Item $item)
    {
        $publishers = Publisher::orderBy("id")->get();

        $authors = [];
        if ($item->item_type === "book") {
            $authors = Author::orderBy("name")->get();
        }

        return view("admin.edit", compact("item", "publishers", "authors"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Item $item)
    {
        $rules = [
            "title" => "required|string|max:200",
            "item_type" => "required|string|max:50",
            "publisher_id" => "required|integer|exists:publishers,id",
            "metadata" => "array",
        ];

        if ($request->input("item_type") === "book") {
            $rules["author_id"] = "required|integer|exists:authors,id";
        }

        $request->validate($rules);

        $item->title = $request->input("title");
        $item->item_type = $request->input("item_type");
        $item->publisher_id = $request->input("publisher_id");

        $metadata = $request->input("metadata", []);

        if ($item->item_type === "book" && $request->has("author_id")) {
            $metadata["author_id"] = (int) $request->input("author_id");
        }

        if (is_array($metadata)) {
            foreach ($metadata as $key => &$value) {
                if (
                    is_string($value) &&
                    (str_starts_with($value, "{") ||
                        str_starts_with($value, "["))
                ) {
                    $decodedValue = json_decode($value, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $value = $decodedValue;
                    }
                }
            }
        }

        $item->metadata = $metadata;
        $item->save();

        return redirect()
            ->route("items.index", ["page" => $request->input("page", 1)])
            ->with("success", "Item updated successfully");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Item $item)
    {
        $item->delete();

        return redirect()
            ->route("items.index")
            ->with("success", "Item has been deleted");
    }
}