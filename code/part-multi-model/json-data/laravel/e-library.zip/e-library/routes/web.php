<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\PublisherController;
use App\Http\Controllers\ItemController;

Route::get('/', function () {
    return view('welcome');
});

Route::resource(
    'authors',
     AuthorController::class
);

Route::resource(
    'publishers',
    PublisherController::class
);

Route::resource(
    'items',
    ItemController::class
);
